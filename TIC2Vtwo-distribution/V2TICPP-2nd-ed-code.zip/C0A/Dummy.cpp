//: C0A:Dummy.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// To give the makefile at least one target 
// for this directory
int main() {} ///:~
